/*
 * Barrel.cpp
 *
 *  Created on: 2009-03-13
 *      Author: zby
 */

#include "Barrel.h"

namespace AALBarrels // name space
{


Barrel::Barrel()
{
	// TODO Auto-generated constructor stub
	this->color = Barrel::NONE;
}

Barrel::Barrel(Color c)
{
	this->color = c;
}

Barrel::Barrel(const Barrel& another)
{
	this->color = another.color;
}

Barrel::~Barrel()
{
	// TODO Auto-generated destructor stub
	return;
}

int Barrel::compareBarrels(const Barrel& it) const
{
	int r = (this->color - it.color);
	if(r<0) r = -1;
	if(r>0) r = 1;
	return r;
}

Barrel::Color Barrel::getColor() const
{
	return this->color;
}

void Barrel::setColor(Color c)
{
	this->color = c;
}

char Barrel::printBarrel() const
{
	char c = '\0';
	switch(this->getColor())
	{
	case Barrel::RED:
		c = 'R';
		break;
	case Barrel::BLUE:
		c = 'B';
		break;
	case Barrel::GREEN:
		c = 'G';
	default:
		break;
	}
	return c;
}

Barrel Barrel::readBarrel(char s)
{
	Color c;
	switch(s)
	{
	case 'R':
		c = Barrel::RED;
		break;
	case 'B':
		c = Barrel::BLUE;
		break;
	case 'G':
		c = Barrel::GREEN;
	default:
		break;
	}
	Barrel b(c);
	return b;
}


};
