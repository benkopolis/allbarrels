/*
 * InclinedPlane.cpp
 *
 *  Created on: 2009-03-13
 *      Author: zby
 */

#include <iostream>
#include <vector>
#include <utility>
#include <cstdlib>
#include <ctime>


#include "InclinedPlane.h"
#include "Barrel.h"
#include "BarrelException.h"


namespace AALBarrels
{

/**
 * ********************************************************************************
 * ************************* CLASS PUBLIC CONSTRUCTOR *****************************
 * ********************************************************************************
 * ********************** InclinedPlane::InclinedPlane() **************************
 * ********************************************************************************
 */
InclinedPlane::InclinedPlane()
{
	// TODO Auto-generated constructor stub
	this->quantityOfBlue = 0;
	this->quantityOfGreen = 0;
	this->quantityOfRed = 0;
}

/**
 * ********************************************************************************
 * ************************* CLASS PUBLIC DESTRUCTOR ******************************
 * ********************************************************************************
 * *********************** InclinedPlane::~InclinedPlane() ************************
 * ********************************************************************************
 */
InclinedPlane::~InclinedPlane()
{
	// TODO Auto-generated destructor stub
	std::list<Barrel*>::iterator ii = this->list.begin();
	for(; ii!= this->list.begin(); ++ii)
	{
		delete *ii;
	}
}

/**
 * ********************************************************************************
 * *************************** CLASS PUBLIC METHOD ********************************
 * ********************************************************************************
 * ***************** void InclinedPlane::addBarrel(Barrel *b) *********************
 * ********************************************************************************
 */
void InclinedPlane::addBarrel(Barrel *b)
{
	this->list.push_back(b);
	try
	{
		switch(b->getColor())
		{
		case Barrel::RED:
			++this->quantityOfRed;
			break;
		case Barrel::BLUE:
			++this->quantityOfBlue;
			break;
		case Barrel::GREEN:
			++this->quantityOfGreen;
			break;
		default:
			BarrelException c(BarrelException::NoColorSet);
			std::string s("Threw from void InclinedPlane::addBarrel(Barrel *b)");
			c.setMessage(s);
			throw c;
			break;
		}
	} catch(BarrelException e)
	{
		std::cerr << e.getMessage();
	};
}

void InclinedPlane::addBarrel(Barrel** b, int size)
{
	for(int i=0; i<size; ++i)
	{
		this->addBarrel(b[i]);
	}
}

/**
 * ********************************************************************************
 * ************************** CLASS PUBLIC METHOD *********************************
 * ********************************************************************************
 * ****************** void InclinedPlane::printBarrels() const ********************
 * ********************************************************************************
 */
void InclinedPlane::printBarrels() const
{
	std::list<Barrel*>::const_iterator ii = this->list.begin();
	char c = '\0';
	int i = 0;
	for(; ii!=list.end(); ++ii, ++i)
	{
		c = (*ii)->printBarrel();
		std::cout << c;
		if(i%25 == 0)
			std::cout << std::endl;
	}
}

/**
 * ********************************************************************************
 * ************************** CLASS PUBLIC METHOD ********************************
 * ********************************************************************************
 * ************** void InclinedPlane::printBarrels(int index) const ***************
 * ********************************************************************************
 */
void InclinedPlane::printBarrels(int index) const
{
	std::list<Barrel*>::const_iterator ii = this->list.begin();
	char c = '\0';
	int i = 0;
	for(; ii!=list.end(); ++ii, ++i)
	{
		c = (*ii)->printBarrel();
		if(i == index)
			std::cout << "||";
		std::cout << c;
		if(i%25 == 0)
			std::cout << std::endl;
	}
}

/**
 * ********************************************************************************
 * ************************** CLASS PUBLIC METHOD *********************************
 * ********************************************************************************
 * ****************** void InclinedPlane::startSort(SortType s) *******************
 * ********************************************************************************
 */
void InclinedPlane::startSort(SortType s)
{
	if(this->quantityOfGreen < 3)
		return;
	if(s == InclinedPlane::IntelligentSort)
		this->intelligentSort();
}


/**
 * ********************************************************************************
 * ************************** CLASS PUBLIC METHOD *********************************
 * ********************************************************************************
 * ************** Barrel* InclinedPlane::generateBarrels(int size) ****************
 * ********************************************************************************
 */
Barrel** InclinedPlane::generateBarrels(int size)
{
	Barrel **r = new Barrel* [size];
	int i=0, green=0;
	Barrel::Color c=Barrel::NONE;
	srand(time(NULL));
	while(i<size)
	{
		c = (Barrel::Color)(((int)rand())%(int)Barrel::GREEN + 1);
		if(green < 3 && c == Barrel::GREEN)
			++green;
		r[i] = new Barrel(c);
		++i;
	}
	while(i>0 && green < 3)
	{
		--i;
		if(r[i]->getColor() != Barrel::GREEN)
		{
			r[i]->setColor(Barrel::GREEN);
			++green;
		}
	}
	return r;
}


/**
 * ********************************************************************************
 * ************************** CLASS PUBLIC METHOD *********************************
 * ********************************************************************************
 * ************************** void InclinedPlane::clear() *************************
 * ********************************************************************************
 */
void InclinedPlane::clear()
{
	std::list<Barrel*>::iterator ii = this->list.begin();
	for(; ii!= this->list.begin(); ++ii)
	{
		delete *ii;
	}
	this->list.clear();
}




/**
 * 				PRIVATE METHODS OF CLASS INCLINEDPLANE
 */

/**
 * ********************************************************************************
 * ************************** CLASS PRIVATE METHOD ********************************
 * ********************************************************************************
 * ****************** void InclinedPlane::intelligentSort() ***********************
 * ********************************************************************************
 */
std::pair<std::list<Barrel*>::iterator, int>
InclinedPlane::findRight(Barrel::Color e, std::list<Barrel*>::iterator ii)
{
	std::pair<std::list<Barrel*>::iterator, int> ret;
	ret.second = 0;
	++ii;
	while(ii != this->list.end())
	{
		++ret.second;
		if((*ii)->getColor() == e)
		{
			ret.first = ii;
			if(ret.second%3 == 0)
				break;
		}
		++ii;
	}
	return ret;
}


/**
 * ********************************************************************************
 * ************************** CLASS PRIVATE METHOD ********************************
 * ********************************************************************************
 * void InclinedPlane::moveTrios(std::list<Barrel*>::iterator from, std::list<Barrel*>::iterator to, int k, int i)
 * ********************************************************************************
 */
std::list<Barrel *>::iterator InclinedPlane::moveTrios(std::list<Barrel*>::iterator from, std::list<Barrel*>::iterator to, int k, int i)
{
	std::list<Barrel*>::iterator pom = this->list.end();
	--pom;
	Barrel::Color c = (*to)->getColor();
	int l = this->list.size()-i-k-1;

	this->printBarrels();

	if(k % 3 == 2 && l % 3 == 2) 			// 2 i 2
	{
		--to;
		this->swapTrioBehind(to);
	}
	else if(k % 3 == 1 && l % 3 == 1) 		// 1 i 1
	{
		--pom;
		if(pom == to)
		{
			--pom;
			this->swapTrioBefore(pom);
		}
		this->swapTrioBehind(to);
	}
	else if( k % 3 == 2 && l % 3 == 1)  	// 2 i 1
		this->swapTrioBefore(to);
	else if( k % 3 == 1 && l % 3 == 2)		// 1 i 2
	{
		--to;
		this->swapTrioBehind(to);
		to = this->list.end();
		--to; --to;
		this->swapTrioBefore(to);
	}
	else if(k % 3 == 1 && l % 3 == 0)		// 1 i 0
	{
		if(pom == to)
		{
			--pom;
			this->swapTrioBefore(pom);
		}
		--to;
		this->swapTrioBehind(to);
	}
	else if(k % 3 == 2 && l % 3 == 0)		// 2 i 0
	{
		if(pom == to)
		{
			--pom;
			this->swapTrioBefore(pom);
		}
		this->swapTrioBehind(to);
	}
	int lol=0;
	while((*from)->getColor() != c)
	{
		this->printBarrels();
		from = this->swapTrioBehind(from);
		lol++;
	//	std::cout << lol << std::endl;
	}
	return from;
}

/**
 * ********************************************************************************
 * ************************** CLASS PRIVATE METHOD ********************************
 * ********************************************************************************
 * ****************** void InclinedPlane::intelligentSort() ***********************
 * ********************************************************************************
 */
void InclinedPlane::intelligentSort()
{
	int sortedPosition = 0, i =0;
	Barrel *tmp;
	int encRed=0, encBlue=0, encGreen=0;
	bool notSorted = true;
	std::list<Barrel*>::iterator ii, nextGood;
	std::pair<std::list<Barrel*>::iterator, int> info;
	ii = this->list.begin();
	std::cout << "zaczelo sortowac" << std::endl;
	// poczatek petli sortujacej
	for(; ii != this->list.end(); ++ii, ++i)
	{
		switch((*ii)->getColor())
		{
		case Barrel::RED:
			sortedPosition = i;
			++encRed;
			break;
		case Barrel::BLUE:
			if(encRed != this->quantityOfRed)
			{
				info = this->findRight(Barrel::RED, ii);
				tmp = *(info.first);
				ii = this->moveTrios(ii, info.first, info.second, i);
				tmp = *ii;
				// posortowane - tzn zamiast blue jest red - zwiekszamy licznik
				++encRed;
				// i zmieniamy sortedPosition
				sortedPosition = i;
			} else
			{
				++encBlue;
				sortedPosition = i;
			}
			break;
		case Barrel::GREEN:
			if(encRed != this->quantityOfRed)
			{
				info = this->findRight(Barrel::RED, ii);
				tmp = *(info.first);
				ii = this->moveTrios(ii, info.first, info.second, i);
				tmp = *ii;
				// posortowane - tzn zamiast green jest red - zwiekszamy licznik
				++encRed;
				// i zmieniamy sortedPosition
				sortedPosition = i;
			} else if(encBlue != this->quantityOfBlue)
			{
				info = this->findRight(Barrel::BLUE, ii);
				tmp = *(info.first);
				ii = this->moveTrios(ii, info.first, info.second, i);
				tmp = *ii;
				// posortowane - tzn zamiast green jest blue - zwiekszamy licznik
				++encBlue;
				// i zmieniamy sortedPosition
				sortedPosition = i;
			} else
			{
				notSorted = false;
				++encGreen;
			}
			break;
		default:
			break;
		}
		if(notSorted == false)
			break;
	} // KONIEC PETLI FOR, KTORA WYZNACZYLA sortedPosition
	std::cout << std::endl << " KONIEC SORTOWANIA " << std::endl;
}

/**
 * ********************************************************************************
 * ************************** CLASS PRIVATE METHOD ********************************
 * ********************************************************************************
 * std::list<Barrel *>::iterator InclinedPlane::swapTrioBefore(std::list<Barrel *>::iterator last)
 * ********************************************************************************
 */
std::list<Barrel *>::iterator InclinedPlane::swapTrioBefore(std::list<Barrel *>::iterator last)
{
	Barrel *tab;
	--last; --last;
	for(int i=0; i<3; ++i)
	{
		tab = new Barrel(**last);
		this->list.push_back(tab);
		tab = *last;
		last = this->list.erase(last);
		delete tab;
		tab = NULL;
	}
	return last;
}

/**
 * ********************************************************************************
 * ************************** CLASS PRIVATE METHOD ********************************
 * ********************************************************************************
 * std::list<Barrel *>::iterator InclinedPlane::swapTrioBehind(std::list<Barrel *>::iterator first
 * ********************************************************************************
 */
std::list<Barrel *>::iterator InclinedPlane::swapTrioBehind(std::list<Barrel *>::iterator first)
{
	Barrel *tab;
	for(int i=0; i<3; ++i)
	{
		tab = new Barrel(**first);
		this->list.push_back(tab);
		tab = *first;
		first = this->list.erase(first);
		delete tab;
		tab = NULL;
	}
	return first;
}

} // namespace
